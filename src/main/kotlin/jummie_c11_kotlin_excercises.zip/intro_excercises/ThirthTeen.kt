package intro_excercises

fun main() {
    val sum = 90 + 50 + 40
    println("The sum is $sum")
}