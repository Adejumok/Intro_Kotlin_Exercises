package intro_excercises

fun main(){
    val alphabets = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    for(i in alphabets){
        print("$i ")
    }
}