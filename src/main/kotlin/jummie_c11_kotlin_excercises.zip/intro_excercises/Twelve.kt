package intro_excercises

fun main() {
    val char = 'k'
    if (char.isDigit()) println("This character is an integer") else println("This character is an alphabet")
    }